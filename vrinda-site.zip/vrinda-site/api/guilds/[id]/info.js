const { authorize } = require('../../_lib/auth');
const { API, botHeaders } = require('../../_lib/discord');

// Channels and roles of a server, for dropdowns later.
module.exports = async (req, res) => {
  try {
    const a = await authorize(req, res);
    if (!a) return;
    const [c, r] = await Promise.all([
      fetch(`${API}/guilds/${a.id}/channels`, { headers: botHeaders() }),
      fetch(`${API}/guilds/${a.id}/roles`, { headers: botHeaders() }),
    ]);
    if (!c.ok || !r.ok) return res.status(502).json({ error: 'Discord request failed. Is Vrinda in this server?' });
    const channels = (await c.json()).filter((x) => [0, 2, 4, 5, 15].includes(x.type)).map((x) => ({ id: x.id, name: x.name, type: x.type }));
    const roles = (await r.json()).filter((x) => !x.managed && x.name !== '@everyone').map((x) => ({ id: x.id, name: x.name }));
    res.json({ channels, roles });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
};
