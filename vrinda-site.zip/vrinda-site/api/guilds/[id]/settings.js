const { getDb } = require('../../_lib/db');
const { authorize } = require('../../_lib/auth');
const { validate } = require('../../_lib/validate');

module.exports = async (req, res) => {
  try {
    const a = await authorize(req, res);
    if (!a) return;
    const col = (await getDb()).collection('guilds');
    if (req.method === 'GET') {
      const d = await col.findOne({ _id: a.id });
      return res.json({ settings: (d && d.settings) || null, updatedAt: (d && d.updatedAt) || null });
    }
    if (req.method === 'PUT') {
      const err = validate(req.body);
      if (err) return res.status(400).json({ error: err });
      const b = req.body;
      await col.updateOne(
        { _id: a.id },
        { $set: { settings: { master: b.master, wl: b.wl, L: b.L, v: b.v }, updatedAt: new Date(), updatedBy: a.s.uid } },
        { upsert: true }
      );
      return res.json({ ok: true });
    }
    res.setHeader('Allow', 'GET, PUT');
    res.status(405).json({ error: 'Method not allowed' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
};
