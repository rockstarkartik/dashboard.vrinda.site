const str = (x, n) => typeof x === 'string' && x.length <= n;
const isObj = (x) => x && typeof x === 'object' && !Array.isArray(x);

// Returns an error message, or null if the settings object is safe to store.
function validate(b) {
  if (!isObj(b)) return 'Invalid body';
  if (typeof b.master !== 'boolean') return 'master must be true or false';
  if (!Array.isArray(b.wl) || b.wl.length > 50 || !b.wl.every((x) => str(x, 64))) return 'Invalid whitelist';
  if (!isObj(b.L)) return 'Invalid lists';
  const lk = Object.keys(b.L);
  if (lk.length > 20) return 'Too many lists';
  for (const k of lk) {
    const a = b.L[k];
    if (!/^[a-z]{1,20}$/.test(k) || !Array.isArray(a) || a.length > 100 || !a.every((x) => str(x, 64))) return 'Invalid list ' + k;
  }
  if (!isObj(b.v)) return 'Invalid settings';
  const vk = Object.keys(b.v);
  if (vk.length > 400) return 'Too many settings';
  for (const k of vk) {
    if (!/^[a-z]{1,10}\.[a-z0-9]{1,20}(\.[0-9]{1,3})?$/.test(k)) return 'Invalid key ' + k;
    const x = b.v[k];
    if (typeof x === 'boolean' || str(x, 300)) continue;
    if (isObj(x)) {
      if (typeof x.on !== 'boolean') return 'Invalid value for ' + k;
      for (const f of ['o', 'a', 'v']) if (x[f] != null && !str(x[f], 300)) return 'Invalid value for ' + k;
      continue;
    }
    return 'Invalid value for ' + k;
  }
  return null;
}
module.exports = { validate };
