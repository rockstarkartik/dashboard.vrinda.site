const API = 'https://discord.com/api/v10';
const siteUrl = () => (process.env.SITE_URL || '').replace(/\/$/, '');
const redirectUri = () => siteUrl() + '/api/auth/callback';
const ADMIN = 0x8n, MANAGE_GUILD = 0x20n;

// A user may manage a server if they own it, are an Administrator, or have Manage Server.
function canManage(g) {
  if (g.owner) return true;
  const p = BigInt(g.permissions || '0');
  return (p & ADMIN) !== 0n || (p & MANAGE_GUILD) !== 0n;
}
async function exchangeCode(code) {
  const r = await fetch(API + '/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: process.env.DISCORD_CLIENT_ID,
      client_secret: process.env.DISCORD_CLIENT_SECRET,
      grant_type: 'authorization_code',
      code,
      redirect_uri: redirectUri(),
    }),
  });
  return r.json();
}
async function userGet(path, accessToken) {
  const r = await fetch(API + path, { headers: { Authorization: 'Bearer ' + accessToken } });
  if (!r.ok) throw new Error('Discord ' + path + ' failed: ' + r.status);
  return r.json();
}
const botHeaders = () => ({ Authorization: 'Bot ' + process.env.DISCORD_BOT_TOKEN });
module.exports = { API, redirectUri, canManage, exchangeCode, userGet, botHeaders };
