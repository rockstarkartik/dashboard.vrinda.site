const { getSession } = require('./session');

// Checks the login session AND that this user manages the requested server.
async function authorize(req, res) {
  const s = await getSession(req);
  if (!s) { res.status(401).json({ error: 'login' }); return null; }
  const id = String(req.query.id || '');
  if (!/^\d{15,25}$/.test(id) || !s.guilds.some((g) => g.id === id)) {
    res.status(403).json({ error: 'You cannot manage this server.' });
    return null;
  }
  return { s, id };
}
module.exports = { authorize };
