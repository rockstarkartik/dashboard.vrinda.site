const crypto = require('crypto');
const { getDb } = require('./db');
const COOKIE = 'vsid';
const LIFETIME = 24 * 60 * 60; // 1 day, in seconds

function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i < 0) return;
    try { out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); } catch (e) {}
  });
  return out;
}
function sign(v) {
  return crypto.createHmac('sha256', process.env.SESSION_SECRET).update(v).digest('base64url');
}
function setCookie(res, name, value, maxAge) {
  const c = `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
  const prev = res.getHeader('Set-Cookie');
  res.setHeader('Set-Cookie', prev ? [].concat(prev, c) : [c]);
}
async function createSession(res, data) {
  const sid = crypto.randomBytes(32).toString('base64url');
  const db = await getDb();
  const col = db.collection('sessions');
  await col.createIndex({ expiresAt: 1 }, { expireAfterSeconds: 0 });
  await col.insertOne({ _id: sid, ...data, expiresAt: new Date(Date.now() + LIFETIME * 1000) });
  setCookie(res, COOKIE, sid + '.' + sign(sid), LIFETIME);
}
async function getSession(req) {
  const raw = parseCookies(req)[COOKIE];
  if (!raw) return null;
  const [sid, sig] = raw.split('.');
  if (!sid || !sig) return null;
  const a = Buffer.from(sig), b = Buffer.from(sign(sid));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  const db = await getDb();
  const s = await db.collection('sessions').findOne({ _id: sid });
  if (!s || s.expiresAt < new Date()) return null;
  return s;
}
async function destroySession(req, res) {
  const raw = parseCookies(req)[COOKIE];
  if (raw) {
    const db = await getDb();
    await db.collection('sessions').deleteOne({ _id: raw.split('.')[0] });
  }
  setCookie(res, COOKIE, '', 0);
}
module.exports = { parseCookies, setCookie, createSession, getSession, destroySession };
