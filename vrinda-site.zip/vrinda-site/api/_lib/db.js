const { MongoClient } = require('mongodb');
let client;
async function getDb() {
  if (!client) {
    client = new MongoClient(process.env.MONGODB_URI);
    try { await client.connect(); } catch (e) { client = null; throw e; }
  }
  return client.db('vrinda');
}
module.exports = { getDb };
