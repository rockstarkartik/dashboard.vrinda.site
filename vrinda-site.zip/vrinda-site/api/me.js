const { getSession } = require('./_lib/session');
const { API, botHeaders } = require('./_lib/discord');

module.exports = async (req, res) => {
  try {
    const s = await getSession(req);
    if (!s) return res.status(401).json({ error: 'login' });
    // Is the bot inside each server? Discord answers 200 only if it is.
    const guilds = await Promise.all(
      s.guilds.slice(0, 100).map(async (g) => {
        let bot = false;
        try { bot = (await fetch(API + '/guilds/' + g.id, { headers: botHeaders() })).ok; } catch (e) {}
        return { ...g, bot };
      })
    );
    res.json({
      user: { id: s.uid, name: s.name, avatar: s.avatar },
      clientId: process.env.DISCORD_CLIENT_ID,
      guilds,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
};
