const { parseCookies, setCookie, createSession } = require('../_lib/session');
const { exchangeCode, userGet, canManage } = require('../_lib/discord');

module.exports = async (req, res) => {
  try {
    const { code, state } = req.query;
    const cookies = parseCookies(req);
    if (!code || !state || state !== cookies.vstate) {
      return res.status(400).send('Login failed (bad state). Go back and try again.');
    }
    const tok = await exchangeCode(code);
    if (!tok.access_token) return res.status(400).send('Login failed. Go back and try again.');
    const [user, guilds] = await Promise.all([
      userGet('/users/@me', tok.access_token),
      userGet('/users/@me/guilds', tok.access_token),
    ]);
    const manage = guilds.filter(canManage).map((g) => ({ id: g.id, name: g.name, icon: g.icon }));
    await createSession(res, {
      uid: user.id,
      name: user.global_name || user.username,
      avatar: user.avatar,
      guilds: manage,
    });
    setCookie(res, 'vstate', '', 0);
    res.redirect(302, '/');
  } catch (e) {
    console.error(e);
    res.status(500).send('Login failed. Check the Vercel function logs.');
  }
};
