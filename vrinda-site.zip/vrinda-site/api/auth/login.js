const crypto = require('crypto');
const { setCookie } = require('../_lib/session');
const { redirectUri } = require('../_lib/discord');

module.exports = (req, res) => {
  const state = crypto.randomBytes(16).toString('hex');
  setCookie(res, 'vstate', state, 600);
  const p = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    redirect_uri: redirectUri(),
    response_type: 'code',
    scope: 'identify guilds',
    state,
    prompt: 'none',
  });
  res.redirect(302, 'https://discord.com/oauth2/authorize?' + p.toString());
};
