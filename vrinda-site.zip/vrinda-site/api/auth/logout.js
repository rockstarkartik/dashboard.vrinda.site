const { destroySession } = require('../_lib/session');

module.exports = async (req, res) => {
  try { await destroySession(req, res); } catch (e) { console.error(e); }
  res.status(200).json({ ok: true });
};
